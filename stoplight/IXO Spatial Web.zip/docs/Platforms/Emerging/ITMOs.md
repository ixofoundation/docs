---
stoplight-id: 7b0to5luei56v
---

# Internationally-Transferred Mitigation Outcomes (ITMOS)

The beginning of an awesome article...
