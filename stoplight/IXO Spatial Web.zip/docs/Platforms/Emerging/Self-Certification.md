---
stoplight-id: 4ry7clxvp3xx1
---

# Self-Certification

### Certified Fuel Purchases

### Certified Fuel Deliveries

### Certified Emission Reductions
