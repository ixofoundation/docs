---
stoplight-id: t12yd5i8onyim
---

# Validation-and-Verification Bodies

The beginning of an awesome article...
